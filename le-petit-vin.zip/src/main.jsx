import React from 'react';
import ReactDOM from 'react-dom/client';
import LePetitVin from './LePetitVin';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LePetitVin />
  </React.StrictMode>
);
